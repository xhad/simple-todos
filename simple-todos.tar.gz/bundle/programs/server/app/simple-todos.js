(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// simple-todos.js                                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Tasks = new Mongo.Collection("tasks");                                 // 1
                                                                       //
if (Meteor.isServer) {                                                 // 3
  // This code only runs on the server                                 //
  Meteor.publish("tasks", function () {                                // 5
    return Tasks.find({                                                // 6
      $or: [{ "private": { $ne: true } }, { owner: this.userId }]      // 7
    });                                                                //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 15
  // This code only runs on the client                                 //
  Meteor.subscribe("tasks");                                           // 17
                                                                       //
  Template.body.helpers({                                              // 19
    tasks: function () {                                               // 20
      if (Session.get("hideCompleted")) {                              // 21
        // If hide completed is chekced, filter tasks                  //
        return Tasks.find({ checked: { $ne: true } }, { sort: { createdAt: -1 } });
      } else {                                                         //
        //otherwise, return all of the tasks                           //
        return Tasks.find({}, { sort: { createdAt: -1 } });            // 26
      }                                                                //
    },                                                                 //
    hideCompleted: function () {                                       // 29
      return Session.get("hideCompleted");                             // 30
    },                                                                 //
    incompleteCount: function () {                                     // 32
      return Tasks.find({ checked: { $ne: true } }).count();           // 33
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.body.events({                                               // 37
    "submit .new-task": function (event) {                             // 38
                                                                       //
      //prevent defualt browser form submit                            //
      event.preventDefault();                                          // 41
                                                                       //
      //get value from the form element                                //
      var text = event.target.text.value;                              // 44
                                                                       //
      //insert a task into the collection                              //
      Meteor.call("addTask", text);                                    // 47
                                                                       //
      //clear form                                                     //
      event.target.text.value = "";                                    // 50
    },                                                                 //
    "change .hide-completed": function (event) {                       // 52
      Session.set("hideCompleted", event.target.checked);              // 53
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.task.helpers({                                              // 57
    isOwner: function () {                                             // 58
      return this.owner === Meteor.userId();                           // 59
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.task.events({                                               // 63
    "click .toggle-checked": function () {                             // 64
      // Set the check property to the opposite of its current value   //
      Meteor.call("setChecked", this._id, !this.checked);              // 66
    },                                                                 //
    "click .delete": function () {                                     // 68
      Meteor.call("deleteTask", this._id);                             // 69
    },                                                                 //
    "click .delete": function () {                                     // 71
      Meteor.call("deleteTask", this._id);                             // 72
    },                                                                 //
    "click .toggle-private": function () {                             // 74
      Meteor.call("setPrivate", this._id, !this["private"]);           // 75
    }                                                                  //
  });                                                                  //
                                                                       //
  Accounts.ui.config({                                                 // 79
    passwordSignupFields: "USERNAME_ONLY"                              // 80
  });                                                                  //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 84
  addTask: function (text) {                                           // 85
    // Make sure the user is logged in before inserting a task         //
    if (!Meteor.userId()) {                                            // 87
      throw new Meteor.Error("not-authorized");                        // 88
    }                                                                  //
                                                                       //
    Tasks.insert({                                                     // 91
      text: text,                                                      // 92
      createdAt: new Date(),                                           // 93
      owner: Meteor.userId(),                                          // 94
      username: Meteor.user().username                                 // 95
    });                                                                //
  },                                                                   //
  deleteTask: function (taskId) {                                      // 98
    var task = Tasks.findOne(taskId);                                  // 99
    if (task["private"] && task.owner !== Meteor.userId()) {           // 100
      // If the task is private, make sure only the owner can delete it
      throw new Meteor.Error("not-authorized");                        // 102
    }                                                                  //
    Tasks.remove(taskID);                                              // 104
  },                                                                   //
  setChecked: function (taskId, setChecked) {                          // 106
    var task = Tasks.findOne(taskId);                                  // 107
    if (task["private"] && task.owner !== Meteor.userId()) {           // 108
      // If the task is private, make sure only the owner can check if off
      throw new Meteor.Error("not-authorized");                        // 110
    }                                                                  //
                                                                       //
    Tasks.update(taskId, { $set: { checked: setChecked } });           // 113
  },                                                                   //
  setPrivate: function (taskId, setToPrivate) {                        // 115
    var task = Tasks.findOne(taskId);                                  // 116
                                                                       //
    // Make sure only the task owner can make a task private           //
    if (task.owner !== Meteor.userId()) {                              // 119
      throw new Meteor.Error("not-authorized");                        // 120
    }                                                                  //
                                                                       //
    Tasks.update(taskId, { $set: { "private": setToPrivate } });       // 123
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=simple-todos.js.map
